package com.linziyuan29155;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VOIDSPACE implements ModInitializer {
	public static final String MOD_ID = "void-space";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Grassland Dimension Mod loaded!");
	}
}
